@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
title MSC Multiplayer 0.1.10-dev
:menu
cls
echo MSC Multiplayer 0.1.10-dev
echo.
echo 1. Build server
echo 2. Run server (default port 27020)
echo 3. Build client mod
echo 4. Run UDP protocol smoke test (server must already be running)
echo 5. Exit
echo.
set "choice="
set /p "choice=Choose: "

if "%choice%"=="1" (
    dotnet build "src\MSC.Server\MSC.Server.csproj" -c Release
    echo.
    pause
    goto menu
)
if "%choice%"=="2" (
    dotnet run --project "src\MSC.Server\MSC.Server.csproj" -c Release
    echo.
    pause
    goto menu
)
if "%choice%"=="3" goto buildclient
if "%choice%"=="4" (
    python "tools\protocol_smoke_test.py" --host 127.0.0.1 --port 27020
    echo.
    pause
    goto menu
)
if "%choice%"=="5" exit /b 0
echo Invalid choice.
pause
goto menu

:buildclient
echo.
echo Enter the My Summer Car installation folder.
echo Example: C:\Program Files (x86)\Steam\steamapps\common\My Summer Car
echo Do NOT enter the Managed subfolder.
echo.
set "MSC_GAME_DIR="
set /p "MSC_GAME_DIR=Game folder: "
if not defined MSC_GAME_DIR (
    echo ERROR: No folder entered.
    pause
    goto menu
)
if not exist "%MSC_GAME_DIR%\mysummercar_Data\Managed\MSCLoader.dll" (
    echo ERROR: MSCLoader.dll was not found.
    echo Expected: "%MSC_GAME_DIR%\mysummercar_Data\Managed\MSCLoader.dll"
    pause
    goto menu
)
if not exist "%MSC_GAME_DIR%\mysummercar_Data\Managed\UnityEngine.dll" (
    echo ERROR: UnityEngine.dll was not found.
    echo Expected: "%MSC_GAME_DIR%\mysummercar_Data\Managed\UnityEngine.dll"
    pause
    goto menu
)
if not exist "%MSC_GAME_DIR%\mysummercar_Data\Managed\Assembly-CSharp.dll" (
    echo ERROR: Assembly-CSharp.dll was not found.
    echo Expected: "%MSC_GAME_DIR%\mysummercar_Data\Managed\Assembly-CSharp.dll"
    pause
    goto menu
)
echo.
echo Game DLLs found. Building client...
dotnet build "src\MSC.Client\MSC.Client.csproj" -c Release
echo.
pause
goto menu
